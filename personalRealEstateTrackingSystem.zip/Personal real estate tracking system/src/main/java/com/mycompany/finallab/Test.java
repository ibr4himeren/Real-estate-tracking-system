/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finallab;

/**
 *
 * @author ieren
 */
public class Test {

    public static void main(String[] args) {
        Customer b = new Customer("Seybem", "584839374", 45678856, 19);

        Realestate state = new Realestate();

        Apartments apt1 = new Apartments("Strawberry Apartment", "Istanbul,Fatih", 5500000, 800000,8);
        state.Apartments.add(apt1);

        Apartments apt2 = new Apartments("Blueberry Apartment", "Istanbul,Uskudar", 2600000,600000, 5);
        state.Apartments.add(apt2);

        Apartments apt3 = new Apartments("Blackberry Apartment", "Istanbul,Pendik", 1900000,400000, 3);
        state.Apartments.add(apt3);

        Flats flat1 = new Flats("No.16", "Ankara,Mamak", 750000,12000, 3);
        state.Flats.add(flat1);

        Flats flat2 = new Flats("No.19", "Trabzon,Hamsiköy", 590000,9000, 3);
        state.Flats.add(flat2);
        
        Flats flat3 = new Flats("No.7", "Kayseri,Talas", 400000, 7000, 3);
        state.Flats.add(flat3);
          
        Villas v1 = new Villas("Rose Villa", "Mugla", 1100000,6000, 5);
        state.Villas.add(v1);

        Villas v2 = new Villas("Tulip Villa", "İzmir", 1500000,25000, 6);
        state.Villas.add(v2);
        
        state.purchaseRealestate(b, v1, 1500000);

        state.saleByPurchase(b, v1, 6000);
        
        state.rentRealEstate(b, flat3, 7000);
        
        state.saleByRent(b, v2, 5000);
        
        state.getAllApartments();
        
        state.getAllFlats();
        
        state.getAllVillas();
        
        b.changeUsername("Kemal");
        
        b.getPurchasedEstates();
        
        b.getRentedEstates();
        
        b.getAllPayments();
        
        b.getTotalPayment();
        
        state.removeFromPurchasedRealestate(b, v1);
        
        b.getAllPayments();
        
        b.getPurchasedEstates();
        
        state.removeFromRentedRealestate(b, v2);
        
        b.getRentedEstates();
        
       
        
        
       

        
    }
}
