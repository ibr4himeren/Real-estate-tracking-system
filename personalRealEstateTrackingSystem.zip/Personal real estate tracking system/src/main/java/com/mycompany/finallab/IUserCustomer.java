/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.finallab;

/**
 *
 * @author ieren
 */
public interface IUserCustomer {

    String getUsername();

    int getId();

    int getAge();

    String getPhoneNumber();

    void changeUsername(String newUsername);

    int changeId(int newId);

    int changeAge(int newNumber);

    void changePhoneNumber(String newNumber);

}
